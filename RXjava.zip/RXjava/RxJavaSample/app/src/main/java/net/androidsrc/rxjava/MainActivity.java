package net.androidsrc.rxjava;

import android.app.Activity;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.util.Log;

import net.androidsrc.rxjava.fragment.MainFragment;

import java.util.ArrayList;
import java.util.List;

import io.reactivex.Observable;
import io.reactivex.ObservableEmitter;
import io.reactivex.ObservableOnSubscribe;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.functions.Function;
import io.reactivex.observers.DisposableObserver;
import rx.schedulers.Schedulers;

public class MainActivity extends Activity {

    private CompositeDisposable compositeDisposable = new CompositeDisposable();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
            setContentView(R.layout.fragment_main);
//        if (savedInstanceState == null) {
//            getSupportFragmentManager().beginTransaction()
//                    .replace(android.R.id.content, new MainFragment(), this.toString())
//                    .commit();
//        }

        Observable<Note> noteObservable = getObservable();

        compositeDisposable.add(noteObservable.subscribeOn(io.reactivex.schedulers.Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .map(new Function<Note, Note>() {
                    @Override
                    public Note apply(Note note) throws Exception {
                        note.setName(note.getName().toUpperCase());
                        return note;
                    }
                })
                .subscribeWith(getDisposalObserver()));

        compositeDisposable.add(noteObservable.subscribeOn(io.reactivex.schedulers.Schedulers.io())
                .observeOn(io.reactivex.schedulers.Schedulers.newThread())
                .map(new Function<Note, Note>() {
                    @Override
                    public Note apply(Note note) throws Exception {
                        if (note.getName().toUpperCase().startsWith("R")){
                            note.setName(note.getName());
                            return note;
                        }
                        return null;
                    }
                })
                .subscribeWith(get2ndDisposalObserver()));

    }

    private Observable<Note> getObservable(){
        return Observable.create(new ObservableOnSubscribe<Note>(){
            List<Note> noteList=prepareNotes();
            @Override
            public void subscribe(ObservableEmitter<Note> emitter) throws Exception {

                for (Note note:noteList){
                    if (!emitter.isDisposed()){
                        emitter.onNext(note);
                    }
                }

                if (!emitter.isDisposed()){
                    emitter.onComplete();
                }
            }
        });
    }

    private List<Note> prepareNotes() {
        List<Note> notes = new ArrayList<>();
        Note note=new Note();
            note.setName("ranjansasmal");
            note.setRoll(10);
        notes.add(note);
        note=new Note();
        note.setName("sasmalranjan");
        note.setRoll(20);
        notes.add(note);
        note=new Note();
        note.setName("sasmal");
        note.setRoll(11);
        notes.add(note);
        note=new Note();
        note.setName("ranjan");
        note.setRoll(12);
        notes.add(note);

        return notes;
    }

    private DisposableObserver<Note> getDisposalObserver(){
        return new DisposableObserver<Note>() {
            @Override
            public void onNext(Note note) {
                Log.w("result1--",note.getName());
            }

            @Override
            public void onError(Throwable e) {

            }

            @Override
            public void onComplete() {

            }
        };
    }
    private DisposableObserver<Note> get2ndDisposalObserver(){
        return new DisposableObserver<Note>() {
            @Override
            public void onNext(Note note) {
                Log.w("result2--",note.getName());
            }

            @Override
            public void onError(Throwable e) {

            }

            @Override
            public void onComplete() {

            }
        };
    }
}
class Note{
    String Name;
    int Roll;

    Note(){

    }

    void setName(String name){
        this.Name = name;
    }

    String getName(){
        return this.Name;
    }

    void setRoll(int roll){
        this.Roll = roll;
    }

    int getRoll(){
        return this.Roll;
    }
}
