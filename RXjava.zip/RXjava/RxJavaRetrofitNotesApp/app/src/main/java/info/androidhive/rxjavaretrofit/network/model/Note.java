package info.androidhive.rxjavaretrofit.network.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/**
 * Created by ravi on 20/02/18.
 */

public class Note extends BaseResponse{
    @SerializedName("id")
    @Expose
    int ids;

    @SerializedName("note")
    @Expose
    String notes;

    @SerializedName("timestamp")
    @Expose
    String timestamps;

    public int getId() {
        return ids;
    }

    public String getNote() {
        return notes;
    }

    public void setNote(String note) {
        this.notes = note;
    }

    public String getTimestamp() {
        return timestamps;
    }
}
