package info.androidhive.rxjavaretrofit.app;

/**
 * Created by ravi on 20/02/18.
 */

public class Const {
    public static final String BASE_URL = "https://demo.androidhive.info/";
}
