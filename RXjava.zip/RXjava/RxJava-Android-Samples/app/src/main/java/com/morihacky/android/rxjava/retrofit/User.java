package com.morihacky.android.rxjava.retrofit;

public class User {
  public String name;
  public String email;
}
