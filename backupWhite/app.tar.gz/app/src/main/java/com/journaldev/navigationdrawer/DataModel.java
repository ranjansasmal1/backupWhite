package com.journaldev.navigationdrawer;

/**
 * Created by anupamchugh on 10/12/15.
 */
public class DataModel {

    public int icon;
    public String name;

    // Constructor.
    public DataModel(String name) {

       // this.icon = icon;
        this.name = name;
    }
}
