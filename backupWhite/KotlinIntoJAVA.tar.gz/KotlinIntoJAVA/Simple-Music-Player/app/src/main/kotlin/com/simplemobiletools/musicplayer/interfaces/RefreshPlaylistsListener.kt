package com.simplemobiletools.musicplayer.interfaces

interface RefreshItemsListener {
    fun refreshItems()
}
