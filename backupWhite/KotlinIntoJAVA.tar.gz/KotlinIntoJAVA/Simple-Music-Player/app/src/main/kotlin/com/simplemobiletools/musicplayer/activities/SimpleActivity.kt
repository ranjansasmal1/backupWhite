package com.simplemobiletools.musicplayer.activities

import com.simplemobiletools.commons.activities.BaseSimpleActivity

open class SimpleActivity : BaseSimpleActivity()
