package com.simplemobiletools.musicplayer.models

data class Playlist(val id: Int, var title: String)
